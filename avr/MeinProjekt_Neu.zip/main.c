/*
	Programm:		        
  Beschreibung:       

	Autor:              
	Datum:			        30.04.2025
  letzte �nderung:  		
*/

#include "controller.h"

void setup (void)   // Initialisierungen 
{
     
}

int main (void)
{
	setup();
	
	while(1)          // loop()
	{
	  	
		
	}
}
