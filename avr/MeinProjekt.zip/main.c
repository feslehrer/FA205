/*
	Programm:		        
  Beschreibung:       

	Autor:              
	Datum:			        24.04.2017
  letzte �nderung:  		
*/

#include "controller.h"

void setup (void)   // Initialisierungen
{
	
}

int main (void)
{
	setup();
	
	while(1)          // loop()
	{
		
		
	}
}
